# VeganClient — Fabric 1.21.4

VeganClient, Fabric üzerinde çalışan siyah/yeşil temalı, performans odaklı bir client-mod projesidir.

## Dahil olanlar

- Minecraft ana ekranının VeganClient logosu ve özel arayüz ile değiştirilmesi
- Sağ `Shift` tuşu ile açılan HUD kontrol ekranı
- FPS Boost profili
- Armor HUD
- Potion/effect sayacı
- Keystrokes göstergesi
- FPS göstergesi
- Koordinat göstergesi
- Görsel crosshair ayarı

Bu mod yalnızca görsel ve performans yardımcıları sunar. Otomatik saldırı, reach, aim assist, x-ray veya sunucularda haksız avantaj sağlayan herhangi bir hile içermez.

## Kurulum

`build/libs/veganclient-1.0.0.jar` dosyasını Minecraft 1.21.4 Fabric profilindeki `mods` klasörüne koyun. Fabric Loader ve Fabric API de aynı profilde kurulu olmalıdır.

## Derleme

Minecraft 1.21.4 için Java 21 ve Gradle gereklidir:

```bash
cd veganclient-fabric
./gradlew build
```

Çıktı `build/libs/veganclient-1.0.0.jar` dosyasıdır. Jar dosyasını Fabric Loader ve Fabric API ile birlikte `mods` klasörüne koyun.

## Sürüm yaklaşımı

1.21.4, bu ilk sürümün sabit ve tam desteklenen hedefidir. Minecraft 1.21.x sürümleri arasında mappings ve ekran API'leri değişebildiği için 1.21.5–1.21.11 için ayrı build profilleri, her sürümün yayınlanan Fabric mappings/API seti doğrulanarak eklenmelidir. Tek bir jar'ı doğrulanmamış sürümlerde zorla çalıştırmak yerine sürüm başına derleme kullanmak çökme riskini azaltır.