package net.veganclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class VeganTitleScreen extends Screen {
    private static final int GREEN = 0xFF65FF46;
    private static final int MUTED = 0xFFB7FF9E;

    public VeganTitleScreen() {
        super(Text.literal("VeganClient"));
    }

    public static void openIfTitleScreen(MinecraftClient client) {
        if (client.currentScreen instanceof TitleScreen && !(client.currentScreen instanceof VeganTitleScreen)) {
            client.setScreen(new VeganTitleScreen());
        }
    }

    @Override
    protected void init() {
        int center = this.width / 2;
        int buttonTop = Math.min(this.height - 104, this.height / 2 + 40);
        addDrawableChild(ButtonWidget.builder(Text.literal("SINGLEPLAYER"), button -> client.setScreen(new net.minecraft.client.gui.screen.world.SelectWorldScreen(this)))
                .dimensions(center - 100, buttonTop, 200, 24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("MULTIPLAYER"), button -> client.setScreen(new net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen(this)))
                .dimensions(center - 100, buttonTop + 30, 200, 24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("OPTIONS"), button -> client.setScreen(new net.minecraft.client.gui.screen.option.OptionsScreen(this, client.options)))
                .dimensions(center - 100, buttonTop + 60, 96, 24).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("QUIT"), button -> client.scheduleStop())
                .dimensions(center + 4, buttonTop + 60, 96, 24).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, this.width, this.height, 0xFF050806);
        context.fill(0, 0, this.width, 2, GREEN);
        context.fill(0, this.height - 2, this.width, this.height, GREEN);

        int logoSize = Math.min(220, Math.max(150, this.height / 3));
        int logoX = this.width / 2 - logoSize / 2;
        int logoY = Math.max(16, this.height / 2 - logoSize / 2 - 72);
        context.drawTexture(
                net.minecraft.client.render.RenderLayer::getGuiTextured,
                VeganClient.LOGO,
                logoX,
                logoY,
                0.0f,
                0.0f,
                logoSize,
                logoSize,
                1254,
                1254
        );
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("VEGANCLIENT"), this.width / 2, logoY + logoSize + 8, GREEN);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("PERFORMANCE • VISUAL HUD • FABRIC"), this.width / 2, logoY + logoSize + 24, MUTED);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}