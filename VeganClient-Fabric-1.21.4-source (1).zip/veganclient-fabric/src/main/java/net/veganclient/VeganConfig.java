package net.veganclient;

import net.minecraft.client.MinecraftClient;

public final class VeganConfig {
    public boolean fpsBoost = true;
    public boolean armorHud = true;
    public boolean potionHud = true;
    public boolean keystrokes = true;
    public boolean cpsCounter = true;
    public boolean coordinates = true;
    public boolean crosshair = true;

    private boolean profileApplied;

    public void toggle(String module) {
        switch (module) {
            case "fpsBoost" -> fpsBoost = !fpsBoost;
            case "armorHud" -> armorHud = !armorHud;
            case "potionHud" -> potionHud = !potionHud;
            case "keystrokes" -> keystrokes = !keystrokes;
            case "cpsCounter" -> cpsCounter = !cpsCounter;
            case "coordinates" -> coordinates = !coordinates;
            case "crosshair" -> crosshair = !crosshair;
            default -> throw new IllegalArgumentException("Unknown VeganClient module: " + module);
        }
    }

    public boolean isEnabled(String module) {
        return switch (module) {
            case "fpsBoost" -> fpsBoost;
            case "armorHud" -> armorHud;
            case "potionHud" -> potionHud;
            case "keystrokes" -> keystrokes;
            case "cpsCounter" -> cpsCounter;
            case "coordinates" -> coordinates;
            case "crosshair" -> crosshair;
            default -> false;
        };
    }

    public void applyFpsProfile(MinecraftClient client) {
        if (profileApplied) {
            return;
        }

        // Conservative values: this never changes gameplay mechanics or input.
        client.options.getViewDistance().setValue(Math.min(client.options.getViewDistance().getValue(), 10));
        client.options.getEntityDistanceScaling().setValue(
                Math.min(client.options.getEntityDistanceScaling().getValue(), 0.75)
        );
        profileApplied = true;
    }
}