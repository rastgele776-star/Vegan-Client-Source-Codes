package net.veganclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class VeganClient implements ClientModInitializer {
    public static final String MOD_ID = "veganclient";
    public static final String BRAND = "VEGANCLIENT";
    public static final net.minecraft.util.Identifier LOGO =
            net.minecraft.util.Identifier.of(MOD_ID, "textures/gui/vegan_logo.png");
    public static final net.minecraft.util.Identifier ICON =
            net.minecraft.util.Identifier.of(MOD_ID, "icon.png");

    public static final VeganConfig CONFIG = new VeganConfig();
    private static KeyBinding hudMenuKey;

    @Override
    public void onInitializeClient() {
        hudMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.veganclient.open_hud",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.veganclient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(VeganClient::onClientTick);
        HudRenderCallback.EVENT.register(VeganHud::render);
    }

    private static void onClientTick(MinecraftClient client) {
        VeganTitleScreen.openIfTitleScreen(client);

        while (hudMenuKey.wasPressed()) {
            if (client.currentScreen instanceof VeganHudScreen) {
                client.setScreen(null);
            } else if (client.currentScreen == null) {
                client.setScreen(new VeganHudScreen());
            }
        }

        if (CONFIG.fpsBoost && client.options != null) {
            CONFIG.applyFpsProfile(client);
        }
    }
}