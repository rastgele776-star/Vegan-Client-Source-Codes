package net.veganclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public final class VeganHudScreen extends Screen {
    private static final int GREEN = 0xFF65FF46;
    private static final int GREEN_MUTED = 0xFFB7FF9E;
    private static final int CARD = 0xFF111A15;
    private static final int CARD_EDGE = 0xFF2E5A35;

    public VeganHudScreen() {
        super(Text.literal("VeganClient HUD"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int left = centerX - 190;
        int top = Math.max(34, this.height / 2 - 105);

        addDrawableChild(moduleButton("fpsBoost", "FPS BOOST", left, top));
        addDrawableChild(moduleButton("armorHud", "ARMOR HUD", left + 195, top));
        addDrawableChild(moduleButton("potionHud", "POTION HUD", left, top + 34));
        addDrawableChild(moduleButton("keystrokes", "KEYSTROKES", left + 195, top + 34));
        addDrawableChild(moduleButton("cpsCounter", "FPS / CPS", left, top + 68));
        addDrawableChild(moduleButton("coordinates", "COORDINATES", left + 195, top + 68));
        addDrawableChild(moduleButton("crosshair", "CROSSHAIR", left, top + 102));

        addDrawableChild(ButtonWidget.builder(Text.literal("DONE"), button -> close())
                .dimensions(centerX - 60, top + 146, 120, 22)
                .build());
    }

    private ButtonWidget moduleButton(String module, String label, int x, int y) {
        return ButtonWidget.builder(label(module, label), button -> {
            VeganClient.CONFIG.toggle(module);
            button.setMessage(label(module, label));
        }).dimensions(x, y, 185, 26).build();
    }

    private Text label(String module, String name) {
        return Text.literal((VeganClient.CONFIG.isEnabled(module) ? "ON  " : "OFF ") + name);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        drawBackground(context);
        int centerX = this.width / 2;
        int top = Math.max(34, this.height / 2 - 105);
        context.drawCenteredTextWithShadow(this.textRenderer, Text.literal("VEGANCLIENT"), centerX, top - 30, GREEN);
        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.literal("HUD CONTROL  •  RIGHT SHIFT"),
                centerX,
                top - 16,
                GREEN_MUTED
        );
        super.render(context, mouseX, mouseY, delta);
    }

    private void drawBackground(DrawContext context) {
        context.fill(0, 0, this.width, this.height, 0xFF070A08);
        context.fill(0, 0, this.width, 2, GREEN);
        context.fill(0, this.height - 2, this.width, this.height, GREEN);

        int panelLeft = this.width / 2 - 194;
        int panelTop = Math.max(20, this.height / 2 - 122);
        context.fill(panelLeft, panelTop, panelLeft + 388, panelTop + 184, CARD);
        context.fill(panelLeft, panelTop, panelLeft + 388, panelTop + 1, CARD_EDGE);
        context.fill(panelLeft, panelTop + 183, panelLeft + 388, panelTop + 184, CARD_EDGE);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}