package net.veganclient;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

public final class VeganHud {
    private static final int GREEN = 0xFF65FF46;
    private static final int GREEN_SOFT = 0xFFB7FF9E;
    private static final int PANEL = 0xB914211A;
    private static final int PANEL_ACTIVE = 0xD62E5A35;

    private VeganHud() {
    }

    public static void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.options.hudHidden) {
            return;
        }

        int width = client.getWindow().getScaledWidth();
        int height = client.getWindow().getScaledHeight();
        if (VeganClient.CONFIG.armorHud) {
            renderArmor(context, player, width - 150, height - 54);
        }
        if (VeganClient.CONFIG.keystrokes) {
            renderKeystrokes(context, client, 8, height - 92);
        }
        if (VeganClient.CONFIG.coordinates) {
            renderCoordinates(context, player, 8, 8);
        }
        if (VeganClient.CONFIG.cpsCounter) {
            renderStatus(context, client, width - 94, 8);
        }
        if (VeganClient.CONFIG.potionHud) {
            renderPotionCount(context, player, width - 94, 48);
        }
    }

    private static void renderCoordinates(DrawContext context, ClientPlayerEntity player, int x, int y) {
        panel(context, x - 4, y - 4, 112, 28, PANEL);
        String coords = String.format(
                "XYZ %d %d %d",
                (int) Math.floor(player.getX()),
                (int) Math.floor(player.getY()),
                (int) Math.floor(player.getZ())
        );
        context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, Text.literal(coords), x, y + 4, GREEN_SOFT);
    }

    private static void renderStatus(DrawContext context, MinecraftClient client, int x, int y) {
        panel(context, x - 4, y - 4, 90, 28, PANEL);
        String fps = client.getCurrentFps() + " FPS";
        context.drawTextWithShadow(client.textRenderer, Text.literal(fps), x, y + 4, GREEN);
    }

    private static void renderPotionCount(DrawContext context, ClientPlayerEntity player, int x, int y) {
        panel(context, x - 4, y - 4, 90, 28, PANEL);
        String effects = player.getStatusEffects().size() + " EFFECTS";
        context.drawTextWithShadow(MinecraftClient.getInstance().textRenderer, Text.literal(effects), x, y + 4, GREEN_SOFT);
    }

    private static void renderArmor(DrawContext context, ClientPlayerEntity player, int x, int y) {
        panel(context, x - 4, y - 4, 142, 46, PANEL);
        for (int slot = 3; slot >= 0; slot--) {
            ItemStack stack = player.getInventory().getArmorStack(slot);
            int itemX = x + (3 - slot) * 34;
            context.drawItem(stack, itemX, y + 5);
        }
        context.drawTextWithShadow(
                MinecraftClient.getInstance().textRenderer,
                Text.literal("ARMOR"),
                x + 2,
                y + 34,
                GREEN_SOFT
        );
    }

    private static void renderKeystrokes(DrawContext context, MinecraftClient client, int x, int y) {
        key(context, client.options.forwardKey.isPressed(), "W", x + 26, y);
        key(context, client.options.leftKey.isPressed(), "A", x, y + 26);
        key(context, client.options.backKey.isPressed(), "S", x + 26, y + 26);
        key(context, client.options.rightKey.isPressed(), "D", x + 52, y + 26);
        key(context, client.options.jumpKey.isPressed(), "JUMP", x + 78, y + 26);
    }

    private static void key(DrawContext context, boolean pressed, String label, int x, int y) {
        int color = pressed ? PANEL_ACTIVE : PANEL;
        panel(context, x, y, label.equals("JUMP") ? 54 : 24, 22, color);
        context.drawTextWithShadow(
                MinecraftClient.getInstance().textRenderer,
                Text.literal(label),
                x + (label.equals("JUMP") ? 8 : 8),
                y + 7,
                pressed ? GREEN : GREEN_SOFT
        );
    }

    private static void panel(DrawContext context, int x, int y, int width, int height, int color) {
        context.fill(x, y, x + width, y + height, color);
        context.fill(x, y, x + width, y + 1, GREEN);
    }
}